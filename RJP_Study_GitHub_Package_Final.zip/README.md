# RJP Study

Pacote no modelo ChutaXuta/CAP: carregar estes ficheiros no GitHub sem descompactar os ZIPs internos.

## Ficheiros a carregar no repositório

- `.github/workflows/build-rjp-study.yml`
- `RJP_Study_Project.zip`
- `RJP_Study_Admin_Project.zip`
- `README.md`

A GitHub Action descompacta os ZIPs, compila a versão web/PWA e gera os APKs Android por Capacitor.

## Apps

- RJP Study — app principal
- RJP Study Admin — portal administrativo
